package com.example.EmployeeService.exception;

public class ManagerHasRepresentativesException extends RuntimeException {
	public ManagerHasRepresentativesException(String message) {
        super(message);
    }

}
